var myJsonData = [{
	"id": "1",
    	"longitude": "108.501033",
    	"latitude": "-6.974933",
    	"altitude": "100.0",
    	"name": "HRD Office",
    	"description": "Human Resource Department Office"
    }, {
    	"id": "2",
    	"longitude": "108.501170",
    	"latitude": "-6.974484",
    	"altitude": "100.0",
    	"name": "General Manager Room",
    	"description": "General Manager Office"
    }, {
    	"id": "3",
    	"longitude": "108.500363",
    	"latitude": "--6.974161",
    	"altitude": "100.0",
    	"name": "Security",
    	"description": "Security Office and Rescue"
    }, {
    	"id": "4",
    	"longitude": "108.499660",
    	"latitude": "-6.974647",
    	"altitude": "100.0",
    	"name": "Marketig Office",
    	"description": "Marketing Department Office"
    }, {
    	"id": "5",
    	"longitude": "108.500290",
    	"latitude": "-6.975761",
    	"altitude": "100.0",
    	"name": "IT Suport",
    	"description": "IT Department Office"
    }, {
    	"id": "6",
    	"longitude": "108.500553",
    	"latitude": "-6.974796",
    	"altitude": "100.0",
    	"name": "Hospital",
    	"description": "Rumah Sakit Bandara Internasional Majalengaka"
}];