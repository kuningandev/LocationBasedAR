var myJsonData = [{
	"id": "1",
    	"longitude": "108.501033",
    	"latitude": "-6.974933",
    	"altitude": "100.0",
    	"name": "Coffee Moonbuck",
    	"description": "Relax your body with a cup of Coffee"
    }, {
    	"id": "2",
    	"longitude": "108.501170",
    	"latitude": "-6.974484",
    	"altitude": "100.0",
    	"name": "Sundanese Resto",
    	"description": "Eat Eat Eaten..."
    }, {
    	"id": "3",
    	"longitude": "108.500363",
    	"latitude": "--6.974161",
    	"altitude": "100.0",
    	"name": "Tegal Food",
    	"description": "The Indonesian Original Taste"
    }, {
    	"id": "4",
    	"longitude": "108.499660",
    	"latitude": "-6.974647",
    	"altitude": "100.0",
    	"name": "MANG OLEH",
    	"description": "Majalengka Gift shop"
    }, {
    	"id": "5",
    	"longitude": "108.500290",
    	"latitude": "-6.975761",
    	"altitude": "100.0",
    	"name": "IndoApril",
    	"description": "Mini Market"
}];