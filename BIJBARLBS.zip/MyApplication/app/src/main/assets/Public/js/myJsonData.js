var myJsonData = [{
	"id": "1",
    	"longitude": "108.501033",
    	"latitude": "-6.974933",
    	"altitude": "100.0",
    	"name": "Masjid",
    	"description": "Tersedia sarung dan mukena untuk sholat"
    }, {
    	"id": "2",
    	"longitude": "108.501170",
    	"latitude": "-6.974484",
    	"altitude": "100.0",
    	"name": "Baby Room",
    	"description": "Tempat memberikan ASI"
    }, {
    	"id": "3",
    	"longitude": "108.500363",
    	"latitude": "--6.974161",
    	"altitude": "100.0",
    	"name": "Smoking Area",
    	"description": "Area merokok"
    }, {
    	"id": "4",
    	"longitude": "108.499660",
    	"latitude": "-6.974647",
    	"altitude": "100.0",
    	"name": "Terminal BUS",
    	"description": "Area parkir bus"
    }, {
    	"id": "5",
    	"longitude": "108.500290",
    	"latitude": "-6.975761",
    	"altitude": "100.0",
    	"name": "Restoran",
    	"description": "Tersedia masakan sunda dan masakan padang"
    }, {
    	"id": "6",
    	"longitude": "108.500553",
    	"latitude": "-6.974796",
    	"altitude": "100.0",
    	"name": "Toilet",
    	"description": "Modern toilet, kebersihan terjaga"
}];