var myJsonData = [{
	    "id": "1",
    	"longitude": "108.501033",
    	"latitude": "-6.974933",
    	"altitude": "100.0",
    	"name": "Money Charger",
    	"description": "Tempat Penukaran Uang"
    }, {
    	"id": "2",
    	"longitude": "108.501170",
    	"latitude": "-6.974484",
    	"altitude": "100.0",
    	"name": "Tiket",
    	"description": "Tempat pembelian tiket dan check in pesawat"
    }, {
    	"id": "3",
    	"longitude": "108.500363",
    	"latitude": "--6.974161",
    	"altitude": "100.0",
    	"name": "Imigration",
    	"description": "Pengecekan dokumen keimigrasian"
}];