package com.bijb.ar.lbs.ARview;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.daimajia.slider.library.SliderLayout;
import com.bijb.ar.lbs.R;
import com.gc.materialdesign.views.ButtonRectangle;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;



public class PoiDetailActivity extends AppCompatActivity implements View.OnClickListener {

    public static final String EXTRAS_KEY_POI_ADDR = "address";
    public static final String EXTRAS_KEY_POI_DESCR = "description";
    public static final String EXTRAS_KEY_POI_ID = "id";
    public static final String EXTRAS_KEY_POI_LAT = "latitude";
    public static final String EXTRAS_KEY_POI_LNG = "longitude";
    public static final String EXTRAS_KEY_POI_PHONE = "phone";
    public static final String EXTRAS_KEY_POI_TITLE = "title";
    private String alamat;
    private ButtonRectangle btnGetTransport;
    private Button btnGetDirection;
    private String deskripsi;
    private SliderLayout imgSlider;
    private LatLng lokasiTujuan;
    private Toolbar mToolbar;
    private GoogleMap map;
    private String nama;
    private String telepon;
    private TextView tvAlamat;
    private TextView tvDeskripsi;
    private TextView tvNama;
    private TextView tvTelepon;


    private void initialize() {
        this.btnGetDirection = ((Button) findViewById(R.id.btnDirection));
        this.btnGetDirection.setOnClickListener(this);
    }

    private void setTeksView() {
        this.tvAlamat.setText(this.alamat);
        this.tvTelepon.setText(this.telepon);
        this.tvDeskripsi.setText(this.deskripsi);
    }

    private void setupMap() {

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        this.map.setMyLocationEnabled(true);
        this.map.addMarker(new MarkerOptions().position(new LatLng(this.lokasiTujuan.latitude, this.lokasiTujuan.longitude)).title(this.nama));
        this.map.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(this.lokasiTujuan.latitude, this.lokasiTujuan.longitude), 10.0F));
        this.map.getUiSettings().setZoomControlsEnabled(true);
        this.map.getUiSettings().setZoomGesturesEnabled(true);
    }

    private void setupToolbar()
    {
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.mToolbar.setTitleTextColor(getResources().getColor(R.color.colorToolbarText));
        this.mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            public void onClick(View paramAnonymousView) {
                PoiDetailActivity.this.onBackPressed();
            }
        });
    }
    @Override
    public void onClick(View v) {
        if (v == this.btnGetDirection) {
            if (v == this.btnGetDirection) {
                startActivity(new Intent("android.intent.action.VIEW", Uri.parse("http://maps.google.com/maps?daddr=" + this.lokasiTujuan.latitude + "," + this.lokasiTujuan.longitude)));
            }
            if (v == this.btnGetTransport) {

            }
        }
    }

    protected void onCreate(Bundle paramBundle)
    {
        super.onCreate(paramBundle);
        setContentView(R.layout.activity_poidetail);
        initialize();
        Bundle localBundle = getIntent().getExtras();
        if (localBundle != null)
        {
            this.nama = localBundle.getString("title");
            this.alamat = localBundle.getString("address");
            this.telepon = localBundle.getString("phone");
            this.deskripsi = localBundle.getString("description");
            this.lokasiTujuan = new LatLng(localBundle.getDouble("latitude"), localBundle.getDouble("longitude"));
        }
        this.mToolbar = ((Toolbar)findViewById(R.id.toolbar));

    }

   protected void onStop()
    {
        super.onStop();
    }
}
