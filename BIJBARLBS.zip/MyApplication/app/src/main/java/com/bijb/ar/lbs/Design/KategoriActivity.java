package com.bijb.ar.lbs.Design;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.View;

import com.bijb.ar.lbs.*;


public class KategoriActivity extends AppCompatActivity {
    CardView btnInfo1,btnInfo2,btnInfo3,btnInfo4,btnInfo5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kategori);

        btnInfo1 = (CardView) findViewById(R.id.kat1);
        btnInfo2 = (CardView) findViewById(R.id.kat2);
        btnInfo3 = (CardView) findViewById(R.id.kat3);
        btnInfo4 = (CardView) findViewById(R.id.kat4);
        btnInfo5 = (CardView) findViewById(R.id.kat5);

        btnInfo1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.bijb.ar.lbs.Design.KategoriActivity.this, ARView1.class);
                com.bijb.ar.lbs.Design.KategoriActivity.this.startActivity(intent);
            }
        });

        btnInfo2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.bijb.ar.lbs.Design.KategoriActivity.this, ARView2.class);
                com.bijb.ar.lbs.Design.KategoriActivity.this.startActivity(intent);
            }
        });

        btnInfo3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.bijb.ar.lbs.Design.KategoriActivity.this, ARView3.class);
                com.bijb.ar.lbs.Design.KategoriActivity.this.startActivity(intent);
            }
        });

        btnInfo4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.bijb.ar.lbs.Design.KategoriActivity.this, ARView4.class);
                com.bijb.ar.lbs.Design.KategoriActivity.this.startActivity(intent);
            }
        });

        btnInfo5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.bijb.ar.lbs.Design.KategoriActivity.this, ARView5.class);
                com.bijb.ar.lbs.Design.KategoriActivity.this.startActivity(intent);
            }
        });
    }

    }


