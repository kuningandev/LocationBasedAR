package com.bijb.ar.lbs.Design;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.View;
import com.bijb.ar.lbs.R;

public class MainActivity extends AppCompatActivity {

    CardView menuScan,menuAbout,menuexit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        menuScan =  findViewById(R.id.menu1);
        menuScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentToKategori = new Intent(MainActivity.this, KategoriActivity.class);
                startActivity (intentToKategori);
            }
        });

        menuAbout =  findViewById(R.id.menu3);
        menuAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentToAbout = new Intent(MainActivity.this, About.class);
                startActivity (intentToAbout);
            }
        });

        menuexit = findViewById(R.id.menu4);
        menuexit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                close();
            }
        });
    }

    public void close(){

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Apakah anda ingin menutup aplikasi ini ?")
                .setCancelable(false)
                .setPositiveButton("Ya",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                MainActivity.this.finish();
                            }
                        })
                .setNegativeButton("Tidak",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();

                    }
                }).show();
    }

    }
