package com.bijb.ar.lbs;

import android.content.Intent;
import android.hardware.SensorManager;
import android.location.LocationListener;
import android.net.Uri;
import android.widget.Toast;

import com.wikitude.architect.ArchitectView;
import com.wikitude.architect.StartupConfiguration;

import com.bijb.ar.lbs.ARview.AbstractArchitectCamActivity;
import com.bijb.ar.lbs.ARview.ArchitectViewHolderInterface;
import com.bijb.ar.lbs.ARview.LocationProvider;
import com.bijb.ar.lbs.ARview.PoiDetailActivity;
import com.bijb.ar.lbs.ARview.WikitudeSDKConstants;


public class ARView5 extends AbstractArchitectCamActivity {

    private long lastCalibrationToastShownTimeMillis = System.currentTimeMillis();

    @Override
    protected StartupConfiguration.CameraPosition getCameraPosition() {
        return StartupConfiguration.CameraPosition.DEFAULT;
    }

    @Override
    protected boolean hasGeo() {
        return true;
    }

    @Override
    protected boolean hasIR() {
        return false;
    }

    @Override
    public String getActivityTitle() {
        return "";
    }

    @Override
    public String getARchitectWorldPath() {
        return "BackOffice/index.html";
    }

    @Override
    public ArchitectView.ArchitectUrlListener getUrlListener() {
        return new ArchitectView.ArchitectUrlListener() {
            public boolean urlWasInvoked(String paramAnonymousString) {
                Uri localUri = Uri.parse(paramAnonymousString);
                if ("markerselected".equalsIgnoreCase(localUri.getHost())) {
                    Intent localIntent = new Intent(ARView5.this, PoiDetailActivity.class);
                    localIntent.putExtra("id", String.valueOf(localUri.getQueryParameter("id")));
                    localIntent.putExtra("title", String.valueOf(localUri.getQueryParameter("title")));
                    localIntent.putExtra("address", String.valueOf(localUri.getQueryParameter("address")));
                    localIntent.putExtra("phone", String.valueOf(localUri.getQueryParameter("phone")));
                    localIntent.putExtra("description", String.valueOf(localUri.getQueryParameter("description")));
                    localIntent.putExtra("latitude", Double.valueOf(localUri.getQueryParameter("latitude")));
                    localIntent.putExtra("longitude", Double.valueOf(localUri.getQueryParameter("longitude")));

                    ARView5.this.startActivity(localIntent);
                }
                return true;
            }
        };
    }



    @Override
    public int getContentViewId() {
        return R.layout.activity_arview;
    }

    @Override
    public String getWikitudeSDKLicenseKey() {
        return WikitudeSDKConstants.WIKITUDE_SDK_KEY;
    }

    @Override
    public int getArchitectViewId() {
        return R.id.architectView;
    }

    @Override
    public ILocationProvider getLocationProvider(LocationListener locationListener) {
        return new LocationProvider(this, locationListener);
    }



    @Override
    public ArchitectView.SensorAccuracyChangeListener getSensorAccuracyListener() {
        return new ArchitectView.SensorAccuracyChangeListener() {
            @Override
            public void onCompassAccuracyChanged( int accuracy ) {
				/* UNRELIABLE = 0, LOW = 1, MEDIUM = 2, HIGH = 3 */
                if ( accuracy < SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM && ARView5.this != null && !ARView5.this.isFinishing() && System.currentTimeMillis() - ARView5.this.lastCalibrationToastShownTimeMillis > 5 * 1000) {
                    Toast.makeText(ARView5.this, R.string.compass_accuracy_low, Toast.LENGTH_LONG).show();
                    ARView5.this.lastCalibrationToastShownTimeMillis = System.currentTimeMillis();
                }
            }
        };
    }

    @Override
    public float getInitialCullingDistanceMeters() {
        return ArchitectViewHolderInterface.CULLING_DISTANCE_DEFAULT_METERS;

    }

}

